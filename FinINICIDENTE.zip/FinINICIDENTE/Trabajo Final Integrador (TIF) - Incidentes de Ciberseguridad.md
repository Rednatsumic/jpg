# Trabajo Final Integrador (TIF) - Incidentes de Ciberseguridad

## Descripción General

Esta aplicación web Java simula diversas vulnerabilidades de ciberseguridad y demuestra sus respectivas soluciones. Está diseñada para ser ejecutable en Eclipse y desplegable como un archivo WAR en un servidor como Apache Tomcat. El objetivo es proporcionar ejemplos prácticos de ataques comunes y las mejores prácticas para mitigarlos.

## Requisitos del Sistema

- Java Development Kit (JDK) 8 o superior
- Apache Maven 3.x
- Apache Tomcat 9.x
- MySQL Server 8.x
- Eclipse IDE (opcional, para desarrollo)

## Configuración de la Base de Datos

1.  **Instalar MySQL Server:** Asegúrate de tener MySQL Server instalado y funcionando. Puedes descargarlo desde la página oficial de MySQL.

2.  **Crear la Base de Datos y Tablas:**
    Accede a tu cliente MySQL (por ejemplo, `mysql` en la terminal) como usuario `root` (o un usuario con privilegios para crear bases de datos y usuarios).

    ```bash
    mysql -u root -p
    ```
    (Ingresa la contraseña de root si la tienes configurada. Si no, es posible que no te pida contraseña o que necesites configurarla primero.)

    Ejecuta el siguiente script SQL para crear la base de datos `ciberseguridad_db` y las tablas necesarias (`users`, `products`, `comments`):

    ```sql
    CREATE DATABASE IF NOT EXISTS ciberseguridad_db;
    USE ciberseguridad_db;

    CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        role VARCHAR(20) NOT NULL
    );

    CREATE TABLE IF NOT EXISTS products (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        description TEXT,
        price DECIMAL(10, 2) NOT NULL,
        user_id INT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS comments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        product_id INT NOT NULL,
        user_id INT NOT NULL,
        content TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );

    INSERT IGNORE INTO users (username, password, email, role) VALUES
    ('admin', 'adminpass', 'admin@example.com', 'admin'),
    ('user1', 'user1pass', 'user1@example.com', 'user'),
    ('user2', 'user2pass', 'user2@example.com', 'user');

    INSERT IGNORE INTO products (name, description, price, user_id) VALUES
    ('Laptop', 'Potente laptop para trabajo y juegos.', 1, 1),
    ('Smartphone', 'Último modelo de smartphone con cámara avanzada.', 999.99, 1),
    ('Tablet', 'Tablet ligera y versátil para el día a día.', 349.99, 2),
    ('Smartwatch', 'Reloj inteligente con funciones de salud.', 199.99, 2);
    ```

    **Nota:** La contraseña para el usuario `root` de MySQL en el archivo `DBConnection.java` está configurada como `password`. Si tu configuración de MySQL es diferente, deberás modificar el archivo `src/main/java/com/example/ciberseguridad/util/DBConnection.java` para que coincida con tus credenciales de base de datos.

## Construcción y Despliegue

1.  **Clonar el Repositorio (o usar el código fuente proporcionado):**

    Si recibiste el código fuente en un archivo comprimido, descomprímelo en tu directorio de trabajo.

2.  **Construir el Proyecto con Maven:**

    Navega hasta el directorio raíz del proyecto (`ciberseguridad-app`) en tu terminal y ejecuta el siguiente comando Maven:

    ```bash
    mvn clean install
    ```

    Esto compilará el código, descargará las dependencias y generará el archivo `ciberseguridad-app.war` en el directorio `target/`.

3.  **Desplegar en Apache Tomcat:**

    Copia el archivo `ciberseguridad-app.war` generado en el paso anterior al directorio `webapps` de tu instalación de Tomcat. Por ejemplo:

    ```bash
    sudo cp target/ciberseguridad-app.war /var/lib/tomcat9/webapps/
    ```

    Reinicia el servicio Tomcat para que la aplicación se despliegue:

    ```bash
    sudo service tomcat9 restart
    ```

## Acceso a la Aplicación

Una vez desplegada, la aplicación estará accesible en tu navegador en la siguiente URL (asumiendo que Tomcat se ejecuta en el puerto 8080):

`http://localhost:8080/ciberseguridad-app/`

## Vulnerabilidades Demostradas y Soluciones

La aplicación incluye secciones para demostrar cada vulnerabilidad y su solución. A continuación, se detalla cada una:

### 1. Inyección SQL

-   **Vulnerable:** `http://localhost:8080/ciberseguridad-app/vulnerable/sql-injection`
    -   **Ataque:** Intenta iniciar sesión con `username: ' or '1'='1` y cualquier contraseña. Esto debería permitir el acceso sin credenciales válidas.
    -   **Explicación:** La aplicación construye la consulta SQL concatenando directamente la entrada del usuario, lo que permite a un atacante modificar la lógica de la consulta.
-   **Segura:** `http://localhost:8080/ciberseguridad-app/secure/sql-injection`
    -   **Solución:** Se utilizan `PreparedStatement` para parametrizar las consultas SQL, asegurando que la entrada del usuario se trate como datos y no como parte del código SQL.

### 2. Inyección HTML

-   **Vulnerable:** `http://localhost:8080/ciberseguridad-app/vulnerable/html-injection`
    -   **Ataque:** Publica un comentario que contenga etiquetas HTML, como `<b>Texto en negrita</b>` o `<img src=x onerror=alert('XSS')>`. El HTML se renderizará directamente en la página.
    -   **Explicación:** La aplicación no escapa la entrada del usuario antes de mostrarla en la página, permitiendo la inyección de código HTML arbitrario.
-   **Segura:** `http://localhost:8080/ciberseguridad-app/secure/html-injection`
    -   **Solución:** Se utiliza `c:out` de JSTL para escapar automáticamente los caracteres HTML especiales en la salida, previniendo que el navegador interprete la entrada del usuario como código HTML.

### 3. Pérdida de Autenticación

-   **Vulnerable:** `http://localhost:8080/ciberseguridad-app/vulnerable/auth-loss`
    -   **Ataque:** Después de iniciar sesión, observa las cookies del navegador. Podrías encontrar una cookie llamada `username` con el nombre de usuario en texto plano. Además, la aplicación es vulnerable a la fijación de sesión.
    -   **Explicación:** La aplicación no invalida la sesión anterior al iniciar una nueva (fijación de sesión) y almacena información sensible en cookies inseguras.
-   **Segura:** `http://localhost:8080/ciberseguridad-app/secure/auth-loss`
    -   **Solución:** Se invalida la sesión existente y se crea una nueva después de un inicio de sesión exitoso para prevenir la fijación de sesión. No se almacena información sensible en cookies del lado del cliente.

### 4. Exposición de Datos Sensibles

-   **Vulnerable:** `http://localhost:8080/ciberseguridad-app/vulnerable/data-exposure`
    -   **Ataque:** Introduce un ID de usuario (ej. `1`). La respuesta JSON mostrará todos los detalles del usuario, incluyendo la contraseña en texto plano.
    -   **Explicación:** La aplicación recupera y expone datos sensibles (contraseñas) directamente desde la base de datos sin ningún tipo de cifrado o enmascaramiento.
-   **Segura:** `http://localhost:8080/ciberseguridad-app/secure/data-exposure`
    -   **Solución:** La aplicación solo recupera y expone los datos del usuario que no son sensibles (sin la contraseña). Para el almacenamiento de contraseñas, se recomienda el uso de funciones hash seguras (como BCrypt), aunque esta implementación se enfoca en la no exposición en la respuesta.

### 5. Pérdida de Control de Acceso

-   **Vulnerable:** `http://localhost:8080/ciberseguridad-app/vulnerable/access-control`
    -   **Ataque:** Un usuario puede manipular el `productId` en la URL para acceder a productos que no le pertenecen. Por ejemplo, si el `user1` tiene el `productId=3` y el `user2` tiene el `productId=4`, el `user1` puede intentar acceder al `productId=4`.
    -   **Explicación:** La aplicación no verifica si el usuario autenticado tiene los permisos adecuados para acceder al recurso solicitado.
-   **Segura:** `http://localhost:8080/ciberseguridad-app/secure/access-control`
    -   **Solución:** Se implementa una verificación en el servidor para asegurar que el usuario autenticado solo pueda acceder a los productos que le pertenecen, comparando el `user_id` del producto con el ID del usuario logueado.

### 6. Cross-Site Scripting (XSS)

-   **Vulnerable:** `http://localhost:8080/ciberseguridad-app/vulnerable/xss`
    -   **Ataque:** Publica un comentario que contenga un script, como `<script>alert('XSS Attack!');</script>`. El script se ejecutará cuando la página se cargue.
    -   **Explicación:** Similar a la inyección HTML, la aplicación no sanitiza la entrada del usuario antes de mostrarla, permitiendo la ejecución de scripts maliciosos en el navegador del cliente.
-   **Segura:** `http://localhost:8080/ciberseguridad-app/secure/xss`
    -   **Solución:** Se utiliza la biblioteca OWASP ESAPI para sanitizar la entrada del usuario (`ESAPI.encoder().encodeForHTML()`) antes de almacenarla y mostrarla, neutralizando cualquier script malicioso.

## Estructura del Proyecto

El proyecto sigue una estructura Maven estándar y una arquitectura MVC:

```
ciberseguridad-app/
├── pom.xml
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── example/
│   │   │           └── ciberseguridad/
│   │   │               ├── controller/ (Servlets)
│   │   │               ├── dao/ (Data Access Objects)
│   │   │               ├── model/ (Clases de Modelo)
│   │   │               └── util/ (Clases de Utilidad, ej. DBConnection)
│   │   └── webapp/
│   │       ├── WEB-INF/
│   │       │   └── web.xml
│   │       ├── jsp/ (Archivos JSP para las vistas)
│   │       └── index.jsp
└── target/ (Contiene el .war generado)
```

## Contacto

Para cualquier pregunta o comentario, por favor contacta a Manus AI.

